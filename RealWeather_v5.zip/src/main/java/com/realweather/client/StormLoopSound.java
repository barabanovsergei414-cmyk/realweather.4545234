package com.realweather.client;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

import java.util.function.Supplier;

/** Looping sound that follows a supplier: {x, y, z, volume}; returning null stops it. */
public class StormLoopSound extends AbstractTickableSoundInstance {
    private final Supplier<double[]> src;
    private final boolean positional;

    public StormLoopSound(SoundEvent event, boolean positional, float pitch, Supplier<double[]> src) {
        super(event, SoundSource.WEATHER, SoundInstance.createUnseededRandom());
        this.src = src;
        this.positional = positional;
        this.looping = true;
        this.delay = 0;
        this.pitch = pitch;
        this.volume = positional ? 60f : 0.01f;
        this.relative = !positional;
        this.attenuation = positional ? SoundInstance.Attenuation.LINEAR : SoundInstance.Attenuation.NONE;
    }

    @Override
    public void tick() {
        double[] s = src.get();
        if (s == null) {
            this.stop();
            return;
        }
        this.x = s[0];
        this.y = s[1];
        this.z = s[2];
        if (!positional) {
            this.volume = (float) s[3];
        }
    }
}
