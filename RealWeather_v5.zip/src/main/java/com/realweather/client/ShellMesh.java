package com.realweather.client;

import com.mojang.blaze3d.vertex.BufferBuilder;

/** An open tube (rings x sides) of translucent quads; drawn back faces first, then front faces. */
public final class ShellMesh {
    public final int rings, sides;
    private final float[] x, y, z, u, v, r, g, b, a;
    private final float[] cx, cz;

    public ShellMesh(int rings, int sides) {
        this.rings = rings;
        this.sides = sides;
        int n = (rings + 1) * (sides + 1);
        x = new float[n];
        y = new float[n];
        z = new float[n];
        u = new float[n];
        v = new float[n];
        r = new float[n];
        g = new float[n];
        b = new float[n];
        a = new float[n];
        cx = new float[rings + 1];
        cz = new float[rings + 1];
    }

    public void ringCenter(int i, float rx, float rz) {
        cx[i] = rx;
        cz[i] = rz;
    }

    public void set(int i, int j, float px, float py, float pz, float tu, float tv, float cr, float cg, float cb, float ca) {
        int k = i * (sides + 1) + j;
        x[k] = px;
        y[k] = py;
        z[k] = pz;
        u[k] = tu;
        v[k] = tv;
        r[k] = cr;
        g[k] = cg;
        b[k] = cb;
        a[k] = ca;
    }

    /** pass 0 = faces turned away from the camera, pass 1 = faces turned towards it. */
    public void draw(BufferBuilder bb, int pass) {
        int row = sides + 1;
        for (int i = 0; i < rings; i++) {
            for (int j = 0; j < sides; j++) {
                int k00 = i * row + j, k01 = k00 + 1, k10 = (i + 1) * row + j, k11 = k10 + 1;
                float mx = (x[k00] + x[k01]) * 0.5f - cx[i];
                float mz = (z[k00] + z[k01]) * 0.5f - cz[i];
                boolean front = (mx * -cx[i] + mz * -cz[i]) > 0f;
                if (front != (pass == 1)) continue;
                if (a[k00] + a[k01] + a[k10] + a[k11] <= 0.004f) continue;
                Gfx.vert(bb, x[k00], y[k00], z[k00], u[k00], v[k00], r[k00], g[k00], b[k00], a[k00]);
                Gfx.vert(bb, x[k01], y[k01], z[k01], u[k01], v[k01], r[k01], g[k01], b[k01], a[k01]);
                Gfx.vert(bb, x[k11], y[k11], z[k11], u[k11], v[k11], r[k11], g[k11], b[k11], a[k11]);
                Gfx.vert(bb, x[k10], y[k10], z[k10], u[k10], v[k10], r[k10], g[k10], b[k10], a[k10]);
            }
        }
    }
}
