package com.realweather.client;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.realweather.ClientConfig;

/** Per-frame shared values: camera, sun, lighting, wind, distance compression. */
public final class Frame {
    public static ClientLevel level;
    public static Matrix4f modelView = new Matrix4f();
    public static double cx, cy, cz;
    public static float partial;
    public static float time;          // game ticks (with partial)
    public static float far;           // projection far plane
    public static float maxD;          // clouds farther than this are pulled in to this distance
    public static float drawDist;      // config cloud distance

    public static float rx, ry, rz;    // camera right
    public static float ux, uy, uz;    // camera up
    public static float lx, ly, lz;    // camera look

    public static final float[] sun = new float[3];
    public static float dayF, dusk, sunI;
    public static final float[] sunCol = new float[3];
    public static final float[] ambient = new float[3];
    public static final float[] horizon = new float[3];

    public static float windX, windZ;          // unit wind direction
    public static double windOffX, windOffZ;   // how far the cloud field has drifted

    public static void setup(ClientLevel lvl, Camera camera, float partialTick, Matrix4f mv) {
        level = lvl;
        modelView = mv;
        partial = partialTick;
        Vec3 p = camera.getPosition();
        cx = p.x;
        cy = p.y;
        cz = p.z;
        time = lvl.getGameTime() + partialTick;

        Minecraft mc = Minecraft.getInstance();
        far = mc.gameRenderer.getDepthFar();
        maxD = Math.max(60f, far * 0.86f);
        drawDist = ClientConfig.CLOUD_DISTANCE.get();

        Vector3f left = camera.getLeftVector();
        Vector3f up = camera.getUpVector();
        Vector3f look = camera.getLookVector();
        rx = -left.x();
        ry = -left.y();
        rz = -left.z();
        ux = up.x();
        uy = up.y();
        uz = up.z();
        lx = look.x();
        ly = look.y();
        lz = look.z();

        SkyModel.sunDir(lvl, partialTick, sun);
        float sy = sun[1];
        dayF = SkyModel.smoothstep(-0.18f, 0.12f, sy);
        dusk = (float) Math.exp(-Math.pow(sy / 0.16f, 2.0));
        sunI = SkyModel.smoothstep(-0.12f, 0.15f, sy);
        float w = SkyModel.smoothstep(0f, 0.35f, sy);
        sunCol[0] = SkyModel.mix(1.0f, 1.0f, w);
        sunCol[1] = SkyModel.mix(0.42f, 0.95f, w);
        sunCol[2] = SkyModel.mix(0.16f, 0.85f, w);
        ambient[0] = SkyModel.mix(0.045f, 0.64f, dayF) + dusk * 0.15f;
        ambient[1] = SkyModel.mix(0.055f, 0.70f, dayF) + dusk * 0.09f;
        ambient[2] = SkyModel.mix(0.100f, 0.80f, dayF) + dusk * 0.11f;
        SkyModel.horizon(sy, ClientState.skyStorm, ClientState.overcast, horizon);

        windX = (float) Math.cos(ClientState.windAngle);
        windZ = (float) Math.sin(ClientState.windAngle);
        double speed = 0.035 * ClientConfig.WIND_SPEED.get();
        double t = lvl.getGameTime() + (double) partialTick;
        windOffX = windX * speed * t;
        windOffZ = windZ * speed * t;
    }

    /** Light a puff by its outward normal; hf = height inside the cloud (0 base .. 1 top); dark = extra shade. */
    public static void shade(float nx, float ny, float nz, float hf, float dark, float[] out) {
        float ndl = nx * sun[0] + ny * sun[1] + nz * sun[2];
        float direct = SkyModel.smoothstep(-0.30f, 0.90f, ndl);
        float skyL = 0.55f + 0.45f * (0.5f + 0.5f * ny);
        float lit = sunI * (0.30f + 0.70f * hf) * direct;
        float moon = (1f - dayF) * 0.10f * (0.5f + 0.5f * ny);
        float stormDim = 1f - ClientState.skyStorm * 0.30f * ClientConfig.STORM_DARKNESS.get().floatValue();
        float d = (1f - dark * 0.78f) * stormDim;
        out[0] = (ambient[0] * skyL + sunCol[0] * lit * 0.95f + moon * 0.55f) * d;
        out[1] = (ambient[1] * skyL + sunCol[1] * lit * 0.95f + moon * 0.60f) * d;
        out[2] = (ambient[2] * skyL + sunCol[2] * lit * 0.95f + moon * 0.75f) * d;
    }

    /** Terrain height under (x, z). Uses `fallback` when the chunk is not loaded on the client. */
    public static float groundY(double x, double z, float fallback) {
        int bx = (int) Math.floor(x), bz = (int) Math.floor(z);
        if (level != null && level.hasChunk(bx >> 4, bz >> 4)) {
            return level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz);
        }
        return fallback;
    }

    private Frame() {}
}
