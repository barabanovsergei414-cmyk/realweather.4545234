package com.realweather.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.realweather.RealWeather;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;

/** Small rendering helpers shared by all renderers. Vertices are given relative to the camera. */
public final class Gfx {
    public static final ResourceLocation PUFF = tex("puff");
    public static final ResourceLocation STREAK = tex("streak");
    public static final ResourceLocation FUNNEL = tex("funnel");
    public static final ResourceLocation GLOW = tex("glow");
    public static final ResourceLocation BOLT = tex("bolt");
    public static final ResourceLocation WHITE = tex("white");
    public static final ResourceLocation NOISE = tex("noise");

    private Gfx() {}

    private static ResourceLocation tex(String n) {
        return ResourceLocation.fromNamespaceAndPath(RealWeather.MODID, "textures/misc/" + n + ".png");
    }

    /** Make the model-view matrix = camera rotation only (vertices are camera-relative). */
    public static void beginView(Matrix4f modelView) {
        RenderSystem.getModelViewStack().pushMatrix();
        RenderSystem.getModelViewStack().identity();
        RenderSystem.getModelViewStack().mul(modelView);
        RenderSystem.applyModelViewMatrix();
    }

    public static void endView() {
        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.applyModelViewMatrix();
    }

    public static void texState(ResourceLocation tex, boolean additive, boolean depthWrite, boolean depthTest) {
        RWShaders.useTexColor(additive);
        RenderSystem.setShaderTexture(0, tex);
        RenderSystem.enableBlend();
        if (depthTest) {
            RenderSystem.enableDepthTest();
            RenderSystem.depthFunc(515);
        } else {
            RenderSystem.disableDepthTest();
        }
        RenderSystem.depthMask(depthWrite);
        RenderSystem.disableCull();
    }

    public static void resetState() {
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc(515);
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    public static BufferBuilder beginTexColor() {
        return Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
    }

    public static void flush(BufferBuilder bb) {
        MeshData mesh = bb.build();
        if (mesh != null) {
            BufferUploader.drawWithShader(mesh);
        }
    }

    public static void vert(BufferBuilder bb, float x, float y, float z, float u, float v, float r, float g, float b, float a) {
        bb.addVertex(x, y, z).setUv(u, v).setColor(c8(r), c8(g), c8(b), c8(a));
    }

    public static int c8(float v) {
        int i = (int) (v * 255f);
        return i < 0 ? 0 : (i > 255 ? 255 : i);
    }
}
