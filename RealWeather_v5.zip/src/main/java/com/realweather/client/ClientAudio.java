package com.realweather.client;

import com.realweather.ClientConfig;
import com.realweather.RWSounds;
import com.realweather.storm.StormData;
import net.minecraft.client.Minecraft;

/** Keeps the tornado roar and the storm wind running while they matter. */
public final class ClientAudio {
    private static StormLoopSound tornado;
    private static StormLoopSound wind;
    private static boolean tActive;
    private static double tx, ty, tz;
    private static final double[] tp = new double[2];
    private static final double[] tornadoState = new double[4];
    private static final double[] windState = new double[4];

    private ClientAudio() {}

    public static void reset() {
        tornado = null;
        wind = null;
        tActive = false;
    }

    public static void tick(Minecraft mc) {
        if (mc.player == null) return;
        float master = ClientConfig.AMBIENT_SOUND_VOLUME.get().floatValue();
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();

        StormData best = null;
        double bd = Double.MAX_VALUE;
        for (StormData s : ClientState.storms) {
            if (!s.hasTornado() || s.funnelLen(s.age) < 0.5f) continue;
            s.tornadoPos(s.age, tp);
            double dx = tp[0] - px, dz = tp[1] - pz;
            double d = dx * dx + dz * dz;
            if (d < bd) {
                bd = d;
                best = s;
                tx = tp[0];
                tz = tp[1];
            }
        }
        tActive = best != null && bd < 1000.0 * 1000.0 && master > 0.01f;
        if (tActive) {
            ty = Math.max(py, Frame.level != null ? Frame.level.getSeaLevel() : 64) + 20.0;
            ClientState.tornadoRumble = (float) (1.0 - Math.sqrt(bd) / 1000.0);
            if (tornado == null || tornado.isStopped()) {
                tornado = new StormLoopSound(RWSounds.TORNADO_ROAR.get(), true, 0.95f, () -> {
                    if (!tActive) return null;
                    tornadoState[0] = tx;
                    tornadoState[1] = ty;
                    tornadoState[2] = tz;
                    tornadoState[3] = 1.0;
                    return tornadoState;
                });
                mc.getSoundManager().play(tornado);
            }
        } else {
            ClientState.tornadoRumble = 0f;
        }

        float wv = (ClientState.wind * 0.55f + ClientState.skyStorm * 0.25f) * master;
        if (wv > 0.015f) {
            if (wind == null || wind.isStopped()) {
                wind = new StormLoopSound(RWSounds.STORM_WIND.get(), false, 1.0f, () -> {
                    float v = (ClientState.wind * 0.55f + ClientState.skyStorm * 0.25f)
                            * ClientConfig.AMBIENT_SOUND_VOLUME.get().floatValue();
                    if (v < 0.01f) return null;
                    windState[3] = Math.min(1.0f, v);
                    return windState;
                });
                mc.getSoundManager().play(wind);
            }
        }
    }
}
