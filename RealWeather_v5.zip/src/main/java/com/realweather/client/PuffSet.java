package com.realweather.client;

/** A set of cloud puffs in local space (struct-of-arrays). */
public final class PuffSet {
    public int n;
    public float[] x, y, z, size, flat, nx, ny, nz, hf, dark, ap, rot;
    public byte[] kind, variant;

    public PuffSet(int cap) {
        x = new float[cap];
        y = new float[cap];
        z = new float[cap];
        size = new float[cap];
        flat = new float[cap];
        nx = new float[cap];
        ny = new float[cap];
        nz = new float[cap];
        hf = new float[cap];
        dark = new float[cap];
        ap = new float[cap];
        rot = new float[cap];
        kind = new byte[cap];
        variant = new byte[cap];
    }

    public void add(float px, float py, float pz, float s, float fl, float nxx, float nyy, float nzz,
                    float h, float dk, float a, int k, java.util.Random r) {
        if (n >= x.length) {
            grow();
        }
        float len = (float) Math.sqrt(nxx * nxx + nyy * nyy + nzz * nzz);
        if (len < 1e-5f) {
            nxx = 0f;
            nyy = 1f;
            nzz = 0f;
            len = 1f;
        }
        x[n] = px;
        y[n] = py;
        z[n] = pz;
        size[n] = s;
        flat[n] = fl;
        nx[n] = nxx / len;
        ny[n] = nyy / len;
        nz[n] = nzz / len;
        hf[n] = h < 0f ? 0f : (h > 1f ? 1f : h);
        dark[n] = dk;
        ap[n] = a;
        rot[n] = r.nextFloat() * 6.2831855f;
        kind[n] = (byte) k;
        variant[n] = (byte) r.nextInt(4);
        n++;
    }

    private void grow() {
        int c = x.length * 2;
        x = java.util.Arrays.copyOf(x, c);
        y = java.util.Arrays.copyOf(y, c);
        z = java.util.Arrays.copyOf(z, c);
        size = java.util.Arrays.copyOf(size, c);
        flat = java.util.Arrays.copyOf(flat, c);
        nx = java.util.Arrays.copyOf(nx, c);
        ny = java.util.Arrays.copyOf(ny, c);
        nz = java.util.Arrays.copyOf(nz, c);
        hf = java.util.Arrays.copyOf(hf, c);
        dark = java.util.Arrays.copyOf(dark, c);
        ap = java.util.Arrays.copyOf(ap, c);
        rot = java.util.Arrays.copyOf(rot, c);
        kind = java.util.Arrays.copyOf(kind, c);
        variant = java.util.Arrays.copyOf(variant, c);
    }
}
