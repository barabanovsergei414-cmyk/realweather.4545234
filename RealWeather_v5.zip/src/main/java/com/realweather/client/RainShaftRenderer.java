package com.realweather.client;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.realweather.ClientConfig;
import com.realweather.Config;
import com.realweather.storm.StormData;

import java.util.ArrayList;
import java.util.List;

/** The visible column of rain (precipitation core) falling out of a storm's base, plus the mist where it hits the ground. */
public final class RainShaftRenderer {
    private static final int RINGS = 7, SIDES = 30;
    private static final int LAYERS = 3;
    private static final ShellMesh[] MESH = {new ShellMesh(RINGS, SIDES), new ShellMesh(RINGS, SIDES), new ShellMesh(RINGS, SIDES)};
    private static final float[] RAD = {1.0f, 0.82f, 0.64f};
    private static final float[] ALPHA = {0.55f, 0.42f, 0.32f};
    private static final float[] REP = {5f, 4f, 3f};
    private static final float[] SPEED = {0.060f, 0.075f, 0.092f};
    private static final java.util.Map<Integer, Float> GROUND = new java.util.HashMap<>();
    private static final double[] rc = new double[2];

    private RainShaftRenderer() {}

    public static void clearCache() {
        GROUND.clear();
    }

    private static float amount(StormData s, float a) {
        return s.rainAmount() * s.mature(a) * (1f - s.dissipate(a));
    }

    /** Mist at the foot of the shaft goes through the shared puff buffer. */
    public static void emitMist() {
        if (!ClientConfig.RAIN_SHAFTS.get()) return;
        for (StormData s : ClientState.storms) {
            float a = s.age + Frame.partial;
            float amt = amount(s, a);
            if (amt < 0.08f) continue;
            s.rainCenter(rc);
            double cx = rc[0] + s.vx * Frame.partial - s.dirX() * 60.0;
            double cz = rc[1] + s.vz * Frame.partial - s.dirZ() * 60.0;
            float gy = groundOf(s, cx, cz);
            float Rp = s.rainRadius() * (0.55f + 0.45f * s.mature(a));
            float light = 0.38f + 0.45f * Frame.dayF + 0.08f * Frame.dusk;
            int n = Math.max(6, (int) (12 * ClientConfig.qualityFactor()));
            for (int k = 0; k < n; k++) {
                float ang = k * (6.2831855f / n) + Frame.time * 0.004f;
                float rad = Rp * (0.35f + 0.55f * (((k * 41) % 10) / 10f));
                Puffs.finish(cx + Math.cos(ang) * rad, gy + 8f, cz + Math.sin(ang) * rad, 150f * s.size, 0.45f,
                        0.60f * light, 0.64f * light, 0.70f * light, 0.30f * amt, ang, k & 3);
            }
        }
    }

    private static float groundOf(StormData s, double x, double z) {
        Float old = GROUND.get(s.id);
        float fb = old != null ? old : (float) Frame.level.getSeaLevel();
        float g = Frame.groundY(x, z, fb);
        GROUND.put(s.id, g);
        return g;
    }

    public static void draw() {
        if (!ClientConfig.RAIN_SHAFTS.get()) return;
        List<StormData> list = new ArrayList<>();
        for (StormData s : ClientState.storms) {
            float a = s.age + Frame.partial;
            if (amount(s, a) >= 0.03f) list.add(s);
        }
        if (list.isEmpty()) return;
        list.sort((p, q) -> Double.compare(dist2(q), dist2(p)));
        for (StormData s : list) {
            drawShaft(s);
        }
    }

    private static double dist2(StormData s) {
        double dx = s.x - Frame.cx, dz = s.z - Frame.cz;
        return dx * dx + dz * dz;
    }

    private static void drawShaft(StormData s) {
        float a = s.age + Frame.partial;
        float amt = amount(s, a);
        s.rainCenter(rc);
        double cx = rc[0] + s.vx * Frame.partial;
        double cz = rc[1] + s.vz * Frame.partial;
        float Rp = s.rainRadius() * (0.55f + 0.45f * s.mature(a));
        float baseY = Config.CLOUD_BASE_Y.get() + s.baseOffsetY();
        float gy = groundOf(s, cx, cz);
        float bottom = gy - 30f;
        float top = baseY - 4f;
        float height = top - bottom;
        if (height < 10f) return;
        float dirX = s.dirX(), dirZ = s.dirZ();
        float time = Frame.time;
        float light = 0.25f + 0.75f * Frame.dayF + 0.10f * Frame.dusk;
        float darkMul = 1f - 0.35f * ClientState.skyStorm;
        boolean green = s.category >= 3;

        for (int layer = 0; layer < LAYERS; layer++) {
            ShellMesh mesh = MESH[layer];
            float rad = Rp * RAD[layer];
            for (int i = 0; i <= RINGS; i++) {
                float t = i / (float) RINGS;               // 0 bottom .. 1 top
                float y = bottom + height * t;
                double ccx = cx - dirX * 70.0 * (1f - t);
                double ccz = cz - dirZ * 70.0 * (1f - t);
                float dx = (float) (ccx - Frame.cx), dy = (float) (y - Frame.cy), dz = (float) (ccz - Frame.cz);
                float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                float k = dist > Frame.maxD ? Frame.maxD / dist : 1f;
                mesh.ringCenter(i, dx * k, dz * k);
                float vprof = 0.25f + 0.75f * SkyModel.smoothstep(0f, 0.22f, t);
                float fb = LightningRenderer.boost(ccx, y, ccz);
                float far = 1f - SkyModel.smoothstep(0.80f, 1.0f, dist / Frame.drawDist);
                float cr = (0.60f - 0.26f * t) * light * darkMul;
                float cg = (0.65f - 0.27f * t) * light * darkMul;
                float cb = (0.72f - 0.29f * t) * light * darkMul;
                if (green) {
                    cr *= 0.92f;
                    cb *= 0.90f;
                    cg *= 1.05f;
                }
                for (int j = 0; j <= SIDES; j++) {
                    float ang = (j % SIDES) * (6.2831855f / SIDES);
                    float wob = 1f + 0.05f * (float) Math.sin(ang * 4f + i * 0.9f + layer * 2f);
                    float px = dx + (float) Math.cos(ang) * rad * wob;
                    float pz = dz + (float) Math.sin(ang) * rad * wob;
                    float vx = px;
                    float vz = pz;
                    float vdist = (float) Math.sqrt(vx * vx + dy * dy + vz * vz);
                    float nearFade = SkyModel.smoothstep(25f, 140f, vdist);
                    float alpha = ALPHA[layer] * amt * vprof * nearFade * far;
                    float tu = j / (float) SIDES * REP[layer] + layer * 0.37f;
                    float tv = (1f - t) * (height / 70f) - time * SPEED[layer];
                    mesh.set(i, j, px * k, dy * k, pz * k, tu, tv, cr + fb * 0.5f, cg + fb * 0.6f, cb + fb * 0.9f, alpha);
                }
            }
        }

        Gfx.texState(Gfx.STREAK, false, false, true);
        BufferBuilder bb = Gfx.beginTexColor();
        for (int layer = 0; layer < LAYERS; layer++) {
            MESH[layer].draw(bb, 0);
        }
        Gfx.flush(bb);
        bb = Gfx.beginTexColor();
        for (int layer = LAYERS - 1; layer >= 0; layer--) {
            MESH[layer].draw(bb, 1);
        }
        Gfx.flush(bb);
        Gfx.resetState();
    }
}
