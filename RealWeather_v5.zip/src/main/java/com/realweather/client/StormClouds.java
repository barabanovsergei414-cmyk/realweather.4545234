package com.realweather.client;

import com.realweather.ClientConfig;
import com.realweather.Config;
import com.realweather.storm.StormData;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/** Builds and animates the cloud structure of a storm: base, tower, overshooting top, anvil, mammatus, wall cloud, shelf. */
public final class StormClouds {
    private static final int BASE = 0, TOWER = 1, TOP = 2, ANVIL = 3, MAMM = 4, WALL = 5, SHELF = 6;

    private static final class Model {
        PuffSet p;
        long seed;
        float q;
    }

    private static final Map<Integer, Model> CACHE = new HashMap<>();

    private StormClouds() {}

    public static void clearCache() {
        CACHE.clear();
    }

    private static Model model(StormData s) {
        float q = ClientConfig.qualityFactor();
        Model m = CACHE.get(s.id);
        if (m == null || m.seed != s.seed || m.q != q) {
            m = new Model();
            m.seed = s.seed;
            m.q = q;
            m.p = build(s, q);
            CACHE.put(s.id, m);
        }
        return m;
    }

    private static PuffSet build(StormData s, float q) {
        Random r = new Random(s.seed ^ 0x5DEECE66DL);
        float R = s.towerRadius();
        float H = s.towerHeight();
        float AR = s.anvilRadius();
        float sz = (float) (1.0 / Math.pow(q, 0.3));
        float wdx = s.dirX(), wdz = s.dirZ();
        boolean squall = s.kind == StormData.KIND_SQUALL;
        boolean sup = s.kind == StormData.KIND_SUPERCELL;
        PuffSet P = new PuffSet(2600);

        // flat dark base deck
        int nb = (int) (80 * q * (squall ? 1.6f : 1f));
        for (int i = 0; i < nb; i++) {
            float ang = r.nextFloat() * 6.2831855f;
            float rad = (float) Math.sqrt(r.nextFloat());
            float u = (float) Math.cos(ang) * rad, v = (float) Math.sin(ang) * rad;
            float along = u * R * 1.5f, lat = v * R * (squall ? 3.2f : 1.5f);
            float x = wdx * along - wdz * lat, z = wdz * along + wdx * lat;
            float size = (130f + 110f * r.nextFloat()) * s.size * sz;
            float y = size * 0.30f * 0.7f + (r.nextFloat() - 0.5f) * 12f;
            P.add(x, y, z, size, 0.30f, (r.nextFloat() - 0.5f) * 0.3f, -1f, (r.nextFloat() - 0.5f) * 0.3f,
                    0f, 0.62f, rad * 0.35f, BASE, r);
        }

        // cauliflower tower
        int levels = 14;
        for (int l = 0; l < levels; l++) {
            float t = (l + 0.5f) / levels;
            float rr = R * (0.55f + 0.9f * (float) Math.sqrt(t) * (1f - 0.75f * t * t * t));
            float tcx = wdx * t * t * R * 0.9f, tcz = wdz * t * t * R * 0.9f;
            int cnt = (int) ((10 + rr / R * 10) * q * (squall ? 1.3f : 1f));
            for (int k = 0; k < cnt; k++) {
                float ang = r.nextFloat() * 6.2831855f;
                boolean filler = r.nextFloat() < 0.38f;
                float rad = rr * (filler ? 0.25f + 0.4f * r.nextFloat() : 0.82f + 0.28f * r.nextFloat());
                float ex = (float) Math.cos(ang) * rad, ez = (float) Math.sin(ang) * rad;
                float px = ex, pz = ez;
                if (squall) {
                    float along = ex * wdx + ez * wdz;
                    float perp = -ex * wdz + ez * wdx;
                    perp *= 1.9f;
                    along *= 0.8f;
                    px = wdx * along - wdz * perp;
                    pz = wdz * along + wdx * perp;
                }
                float x = tcx + px, z = tcz + pz;
                float y = t * H + (r.nextFloat() - 0.5f) * H / levels * 1.4f;
                float size = (150f + 95f * r.nextFloat()) * s.size * sz * (0.8f + 0.35f * t);
                y = Math.max(y, size * 0.88f * 0.85f - 10f);
                float nxn = (float) Math.cos(ang) * 0.9f, nzn = (float) Math.sin(ang) * 0.9f;
                float nyn = 0.3f + 0.7f * t * t * t;
                if (filler) {
                    nxn *= 0.3f;
                    nzn *= 0.3f;
                    nyn = 0.8f;
                }
                float dk = (filler ? 0.30f : 0.10f) + 0.25f * (1f - t) + (sup ? 0.05f : 0f);
                P.add(x, y, z, size, 0.88f, nxn, nyn, nzn, t, dk, t * 0.9f, TOWER, r);
            }
        }

        // overshooting top
        int nt = (int) (10 * q);
        for (int k = 0; k < nt; k++) {
            float x = wdx * R * 0.9f + (r.nextFloat() - 0.5f) * R * 0.7f;
            float z = wdz * R * 0.9f + (r.nextFloat() - 0.5f) * R * 0.7f;
            float y = H + 10f + r.nextFloat() * 70f * s.size;
            float size = (180f + 90f * r.nextFloat()) * s.size * sz;
            P.add(x, y, z, size, 0.9f, (r.nextFloat() - 0.5f) * 0.5f, 1f, (r.nextFloat() - 0.5f) * 0.5f, 1f, 0f, 0.95f, TOP, r);
        }

        // anvil (positions relative to the top of the tower)
        int na = (int) (320 * q);
        for (int i = 0; i < na; i++) {
            int layer = r.nextFloat() < 0.62f ? 0 : 1;
            float along = -0.35f + 1.35f * (float) Math.pow(r.nextFloat(), 0.85f);
            float lat = (r.nextFloat() * 2f - 1f) * (0.42f + 0.28f * (1f - Math.max(0f, along)));
            if (squall) {
                lat *= 1.9f;
                along *= 0.7f;
            }
            float rad = Math.min(1f, (float) Math.hypot(along, lat / 0.85f) / 1.05f);
            float x = (wdx * along - wdz * lat) * AR;
            float z = (wdz * along + wdx * lat) * AR;
            float y = (layer == 0 ? 0f : -55f * s.size) - rad * 30f * s.size + (r.nextFloat() - 0.5f) * 22f;
            float size = (240f + 90f * r.nextFloat()) * (1f - 0.45f * rad) * s.size * sz;
            P.add(x, y, z, size, layer == 0 ? 0.30f : 0.26f,
                    (r.nextFloat() - 0.5f) * 0.4f, layer == 0 ? 0.85f : -0.75f, (r.nextFloat() - 0.5f) * 0.4f,
                    layer == 0 ? 1f : 0.6f, layer == 0 ? 0.04f : 0.50f, rad * 0.88f, ANVIL, r);
        }

        // mammatus pouches under the anvil
        int nm = (int) (26 * q);
        for (int k = 0; k < nm; k++) {
            float along = 0.1f + 0.7f * r.nextFloat();
            float lat = (r.nextFloat() * 2f - 1f) * 0.45f;
            float rad = Math.min(1f, (float) Math.hypot(along, lat) / 1.0f);
            float x = (wdx * along - wdz * lat) * AR;
            float z = (wdz * along + wdx * lat) * AR;
            float y = -110f * s.size - r.nextFloat() * 60f;
            float size = (55f + 45f * r.nextFloat()) * s.size * sz;
            P.add(x, y, z, size, 0.85f, 0f, -1f, 0f, 0.4f, 0.50f, 0.8f + 0.15f * rad, MAMM, r);
        }

        // wall cloud of a supercell
        if (sup) {
            float ox = -wdx * 0.15f * R - wdz * 0.28f * R;
            float oz = -wdz * 0.15f * R + wdx * 0.28f * R;
            int nw = (int) (16 * q);
            for (int k = 0; k < nw; k++) {
                float ang = r.nextFloat() * 6.2831855f;
                float rad = (float) Math.sqrt(r.nextFloat()) * 125f * s.size;
                float x = ox + (float) Math.cos(ang) * rad;
                float z = oz + (float) Math.sin(ang) * rad;
                float y = -35f * s.size - r.nextFloat() * 15f;
                float size = (80f + 55f * r.nextFloat()) * s.size * sz;
                P.add(x, y, z, size, 0.8f, 0f, -1f, 0f, 0f, 0.72f, rad / (125f * s.size) * 0.6f, WALL, r);
            }
        }

        // shelf cloud on the leading edge
        int ns = (int) ((squall ? 100 : 30) * q);
        float arc = squall ? 1.35f : 0.95f;
        float shelfR = R * (squall ? 2.5f : 1.5f);
        for (int k = 0; k < ns; k++) {
            float theta = (r.nextFloat() * 2f - 1f) * arc;
            float ra = shelfR * (0.85f + 0.3f * r.nextFloat());
            float along = (float) Math.cos(theta) * ra;
            float lat = (float) Math.sin(theta) * ra * (squall ? 1.9f : 1f);
            float x = wdx * along - wdz * lat, z = wdz * along + wdx * lat;
            float y = -16f - r.nextFloat() * 22f;
            float size = (110f + 80f * r.nextFloat()) * s.size * sz;
            P.add(x, y, z, size, 0.28f, wdx * 0.4f, -0.6f, wdz * 0.4f, 0.1f, 0.52f, Math.abs(theta) / arc * 0.5f, SHELF, r);
        }
        return P;
    }

    /** Puffs of one storm for this frame. */
    public static void emit(StormData s) {
        float a = s.age + Frame.partial;
        float g1 = s.tower(a), g2 = s.anvil(a), g3 = s.mature(a), dis = s.dissipate(a);
        if (g1 < 0.02f) return;
        PuffSet P = model(s).p;
        double sx = s.x + s.vx * Frame.partial;
        double sz = s.z + s.vz * Frame.partial;
        float baseY = Config.CLOUD_BASE_Y.get() + s.baseOffsetY();
        float H = s.towerHeight();
        float R = s.towerRadius();
        float hs = 0.35f + 0.65f * g1;
        float sizeG = 0.5f + 0.5f * g1;
        float dissSize = 1f - 0.35f * dis;
        float dissA = 1f - (float) Math.pow(dis, 1.5) * 0.9f;
        float wdx = s.dirX(), wdz = s.dirZ();
        float topH = H * Math.min(1f, g1 / 0.92f);
        double ox = sx + wdx * R * 0.9f * hs;
        double oz = sz + wdz * R * 0.9f * hs;
        float oy = topH - 30f * s.size;

        for (int i = 0; i < P.n; i++) {
            int kind = P.kind[i];
            float ap = P.ap[i];
            float v;
            double wx, wy, wz;
            float alpha;
            float size = P.size[i];
            switch (kind) {
                case BASE:
                    v = StormData.smooth((g1 - ap) / 0.25f);
                    wx = sx + P.x[i] * hs;
                    wz = sz + P.z[i] * hs;
                    wy = baseY + P.y[i];
                    alpha = 0.85f * v;
                    size *= sizeG * (0.4f + 0.6f * v);
                    break;
                case TOWER:
                    v = StormData.smooth((g1 * 1.02f - ap) / 0.18f);
                    wx = sx + P.x[i] * hs;
                    wz = sz + P.z[i] * hs;
                    wy = baseY + P.y[i];
                    alpha = 0.90f * v;
                    size *= sizeG * (0.4f + 0.6f * v);
                    break;
                case TOP:
                    v = StormData.smooth((g1 - 0.88f) / 0.12f);
                    wx = sx + P.x[i] * hs;
                    wz = sz + P.z[i] * hs;
                    wy = baseY + P.y[i];
                    alpha = 0.9f * v;
                    size *= (0.4f + 0.6f * v);
                    break;
                case ANVIL: {
                    v = StormData.smooth((g2 - ap) / 0.14f);
                    float k = 0.45f + 0.55f * v;
                    wx = ox + P.x[i] * k;
                    wz = oz + P.z[i] * k;
                    wy = baseY + oy + P.y[i];
                    alpha = (P.ny[i] > 0f ? 0.80f : 0.74f) * v;
                    size *= (0.5f + 0.5f * v);
                    break;
                }
                case MAMM:
                    v = StormData.smooth((g2 - ap) / 0.10f);
                    wx = ox + P.x[i];
                    wz = oz + P.z[i];
                    wy = baseY + oy + P.y[i];
                    alpha = 0.8f * v;
                    size *= (0.4f + 0.6f * v);
                    break;
                case WALL:
                    v = StormData.smooth((g3 - ap) / 0.4f);
                    wx = sx + P.x[i];
                    wz = sz + P.z[i];
                    wy = baseY + P.y[i] + (1f - v) * 40f;
                    alpha = 0.9f * v;
                    size *= (0.4f + 0.6f * v);
                    break;
                default: // SHELF
                    v = StormData.smooth((g3 - ap) / 0.35f);
                    wx = sx + P.x[i];
                    wz = sz + P.z[i];
                    wy = baseY + P.y[i];
                    alpha = 0.78f * v;
                    size *= (0.4f + 0.6f * v);
                    break;
            }
            if (v <= 0.01f) continue;
            Puffs.emit(wx, wy, wz, size * dissSize, P.flat[i], P.nx[i], P.ny[i], P.nz[i], P.hf[i],
                    P.dark[i], alpha * dissA, P.rot[i], P.variant[i]);
        }

        ShadowCasters.add(sx, baseY, sz, R * 1.5f * hs, 0.80f * g1 * dissA);
        if (g2 > 0.05f) {
            float AR = s.anvilRadius();
            ShadowCasters.add(ox + wdx * AR * 0.30f * g2, baseY + topH, oz + wdz * AR * 0.30f * g2,
                    AR * 0.72f * g2, 0.55f * g2 * dissA);
        }
    }
}
