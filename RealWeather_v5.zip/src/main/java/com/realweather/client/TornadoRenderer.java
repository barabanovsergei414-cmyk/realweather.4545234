package com.realweather.client;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.realweather.ClientConfig;
import com.realweather.Config;
import com.realweather.storm.StormData;

/** Condensation funnel (two shells), ground dust ring and debris cloud. */
public final class TornadoRenderer {
    private static final int RINGS = 28, SIDES = 20;
    private static final ShellMesh INNER = new ShellMesh(RINGS, SIDES);
    private static final ShellMesh OUTER = new ShellMesh(RINGS, SIDES);
    private static final float[] col = new float[3];
    private static final double[] tp = new double[2];

    private TornadoRenderer() {}

    /** Ground height at a storm's tornado, cached per storm so it does not jump when chunks load. */
    private static final java.util.Map<Integer, Float> GROUND = new java.util.HashMap<>();

    public static void clearCache() {
        GROUND.clear();
    }

    public static float ground(StormData s, double x, double z) {
        Float old = GROUND.get(s.id);
        float fb = old != null ? old : (float) Frame.level.getSeaLevel();
        float g = Frame.groundY(x, z, fb);
        GROUND.put(s.id, g);
        return g;
    }

    /** Position of the tornado base for this frame, camera-independent. */
    public static void basePos(StormData s, float a, double[] out) {
        s.tornadoPos(a, out);
        out[0] += s.vx * Frame.partial;
        out[1] += s.vz * Frame.partial;
    }

    public static void emitDust() {
        for (StormData s : ClientState.storms) {
            if (!s.hasTornado()) continue;
            float a = s.age + Frame.partial;
            float len = s.funnelLen(a);
            if (len < 0.5f) continue;
            float w = s.funnelWidth(a);
            basePos(s, a, tp);
            float gy = ground(s, tp[0], tp[1]);
            int cat = Math.max(0, Math.min(5, s.category));
            float rg = StormData.EF_RADIUS[cat] * w * (0.8f + 0.2f * s.size);
            float touch = StormData.smooth((len - 0.5f) / 0.5f);
            float light = 0.30f + 0.55f * Frame.dayF + 0.10f * Frame.dusk;
            float t = Frame.time;
            int n = Math.max(6, (int) (14 * ClientConfig.qualityFactor()));
            for (int k = 0; k < n; k++) {
                float ang = t * 0.055f + k * (6.2831855f / n) + (k % 3) * 0.7f;
                float rad = rg * (1.3f + 0.9f * ((k * 37) % 10) / 10f);
                float h = 3f + 22f * (((k * 53) % 10) / 10f);
                float size = rg * (1.2f + 0.9f * (((k * 29) % 10) / 10f)) + 10f;
                Puffs.finish(tp[0] + Math.cos(ang) * rad, gy + h, tp[1] + Math.sin(ang) * rad, size, 0.65f,
                        0.50f * light, 0.43f * light, 0.36f * light, 0.55f * touch * Math.min(1f, w + 0.2f),
                        ang, k & 3);
            }
            // debris sleeve around the lower funnel
            int m = Math.max(4, (int) (9 * ClientConfig.qualityFactor()));
            for (int k = 0; k < m; k++) {
                float u = 0.08f + 0.5f * (k / (float) m);
                float ang = t * 0.07f * (1.4f - u) + k * 2.399f;
                float rad = rg * (1.0f + 0.9f * u);
                float y = gy + u * 70f;
                float size = rg * (1.0f + 0.6f * u) + 8f;
                Puffs.finish(tp[0] + Math.cos(ang) * rad, y, tp[1] + Math.sin(ang) * rad, size, 0.9f,
                        0.46f * light, 0.40f * light, 0.34f * light, 0.30f * touch * (1f - 0.5f * u), ang, (k + 1) & 3);
            }
        }
    }

    public static void draw() {
        BufferBuilder bb;
        for (StormData s : ClientState.storms) {
            if (!s.hasTornado()) continue;
            float a = s.age + Frame.partial;
            float len = s.funnelLen(a);
            if (len < 0.01f) continue;
            if (!build(s, a, len)) continue;
            Gfx.texState(Gfx.FUNNEL, false, true, true);
            bb = Gfx.beginTexColor();
            OUTER.draw(bb, 0);
            INNER.draw(bb, 0);
            Gfx.flush(bb);
            bb = Gfx.beginTexColor();
            INNER.draw(bb, 1);
            OUTER.draw(bb, 1);
            Gfx.flush(bb);
            Gfx.resetState();
        }
    }

    private static boolean build(StormData s, float a, float len) {
        float w = s.funnelWidth(a);
        basePos(s, a, tp);
        float baseY = Config.CLOUD_BASE_Y.get() + s.baseOffsetY();
        float topY = baseY - s.wallDrop();
        float gy = ground(s, tp[0], tp[1]);
        float fullH = topY - gy;
        if (fullH < 20f) return false;
        float yBot = topY - len * fullH;
        int cat = Math.max(0, Math.min(5, s.category));
        float rg = StormData.EF_RADIUS[cat] * w * (0.8f + 0.2f * s.size);
        float flare = 3.6f - 0.38f * cat;
        float rBottom = Math.max(1.2f, rg * 0.65f) * (0.35f + 0.65f * len);
        float rTop = Math.max(rBottom * 1.15f, Math.min(rg * flare, 0.35f * fullH));
        float shiftX = s.dirX() * 0.22f * fullH;
        float shiftZ = s.dirZ() * 0.22f * fullH;
        float time = Frame.time;
        long sd = s.seed & 1023;
        float touch = StormData.smooth((len - 0.6f) / 0.4f);

        for (int shell = 0; shell < 2; shell++) {
            ShellMesh mesh = shell == 0 ? INNER : OUTER;
            float rs = shell == 0 ? 1f : 1.45f;
            float aS = shell == 0 ? 0.95f : 0.36f;
            float bright = shell == 0 ? 0f : 0.10f;
            for (int i = 0; i <= RINGS; i++) {
                float t = i / (float) RINGS;
                float y = yBot + (topY - yBot) * t;
                float uu = fullH > 1f ? Math.max(0f, Math.min(1f, (y - gy) / fullH)) : 0f;
                float sway = (float) Math.sin(time * 0.09f + uu * 6f + sd) * rg * 0.5f * (1f - uu);
                float curve = (float) Math.pow(uu, 1.6);
                double ccx = tp[0] + shiftX * curve + sway * s.dirZ();
                double ccz = tp[1] + shiftZ * curve - sway * s.dirX();
                float rr = (rBottom + (rTop - rBottom) * (float) Math.pow(t, 1.7)) * rs;

                float dx = (float) (ccx - Frame.cx), dy = (float) (y - Frame.cy), dz = (float) (ccz - Frame.cz);
                float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                float k = dist > Frame.maxD ? Frame.maxD / dist : 1f;
                mesh.ringCenter(i, dx * k, dz * k);
                float fb = LightningRenderer.boost(ccx, y, ccz);
                float fade = 1f - SkyModel.smoothstep(0.80f, 1.0f, dist / Frame.drawDist);
                float tipA = i == 0 ? 0.55f : 1f;
                float alpha = aS * tipA * fade * (0.55f + 0.45f * Math.min(1f, len * 2f));
                for (int j = 0; j <= SIDES; j++) {
                    float ang = (j % SIDES) * (6.2831855f / SIDES);
                    float ca = (float) Math.cos(ang), sa = (float) Math.sin(ang);
                    float wob = 1f + 0.07f * (float) Math.sin(ang * 3f + time * 0.2f + i * 0.7f)
                            + 0.05f * (float) Math.sin(ang * 7f - time * 0.3f + i);
                    float px = dx + ca * rr * wob, pz = dz + sa * rr * wob;
                    Frame.shade(ca, 0.1f, sa, t * 0.6f, 0.45f, col);
                    float base = 0.55f + 0.30f * t + bright;
                    float dust = (1f - SkyModel.smoothstep(0f, 0.35f, t)) * 0.65f * touch;
                    float rC = col[0] * base, gC = col[1] * base, bC = col[2] * base;
                    float lum = 0.30f + 0.55f * Frame.dayF;
                    rC += (0.50f * lum - rC) * dust;
                    gC += (0.43f * lum - gC) * dust;
                    bC += (0.36f * lum - bC) * dust;
                    rC += fb * 0.55f;
                    gC += fb * 0.65f;
                    bC += fb;
                    float tu = j / (float) SIDES * (shell == 0 ? 1.0f : 1.3f) + time * 0.012f * (1.4f - t) * (shell == 0 ? 1f : 0.6f);
                    float tv = t * 3.0f - time * 0.020f;
                    mesh.set(i, j, px * k, (dy + 0f) * k, pz * k, tu, tv, rC, gC, bC, alpha);
                }
            }
        }
        return true;
    }
}
