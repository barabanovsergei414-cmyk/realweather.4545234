package com.realweather.client;

import com.realweather.net.FlashPayload;
import com.realweather.net.StormSyncPayload;
import com.realweather.storm.StormData;

public final class ClientPayloads {
    private ClientPayloads() {}

    public static void onSync(StormSyncPayload p) {
        ClientState.storms.clear();
        ClientState.storms.addAll(p.storms());
        ClientState.worldSeed = p.worldSeed();
        ClientState.windAngle = StormData.windAngle(p.worldSeed());
        ClientState.synced = true;
    }

    public static void onFlash(FlashPayload p) {
        LightningRenderer.addFlash(p);
    }
}
