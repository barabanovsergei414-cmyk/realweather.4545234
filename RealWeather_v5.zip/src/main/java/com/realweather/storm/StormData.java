package com.realweather.storm;

import net.minecraft.network.FriendlyByteBuf;

/**
 * One storm. The same class lives on the server (authoritative) and on the client (copy, ticked locally).
 * All timeline values are in game ticks of the storm's age.
 */
public class StormData {
    public static final int KIND_CELL = 0;      // ordinary single-cell thunderstorm
    public static final int KIND_SUPERCELL = 1; // rotating supercell, wall cloud, can make tornadoes
    public static final int KIND_SQUALL = 2;    // squall line: long shelf cloud, heavy rain, lots of lightning
    public static final int KIND_DRY = 3;       // dry thunderstorm: high base, virga, lightning without much rain

    public static final String[] KIND_NAMES = {"cell", "supercell", "squall line", "dry thunderstorm"};

    /** Radius of the tornado at the ground in blocks, per EF category. */
    public static final float[] EF_RADIUS = {5f, 8f, 13f, 21f, 32f, 48f};
    public static final int[] EF_MPH_MIN = {65, 86, 111, 136, 166, 200};
    public static final int[] EF_MPH_MAX = {85, 110, 135, 165, 200, 260};

    public int id;
    public double x, z;
    public float vx, vz;
    public int age;
    public int kind;
    public float size = 1f;
    public long seed;

    public int towerEnd = 6000;
    public int anvilStart = 3500;
    public int anvilEnd = 12000;
    public int matureStart = 7500;
    public int life = 30000;

    public int tornStart = -1;
    public int tornGrow = 2400;
    public int tornHold = 9000;
    public int tornRope = 2400;
    public int category = -1;

    public static float clamp01(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    public static float smooth(float v) {
        v = clamp01(v);
        return v * v * (3f - 2f * v);
    }

    public void tick() {
        age++;
        x += vx;
        z += vz;
    }

    // ---- growth stages (a = age + partial tick) ----
    public float tower(float a) {
        return smooth(a / towerEnd);
    }

    public float anvil(float a) {
        return smooth((a - anvilStart) / (float) Math.max(1, anvilEnd - anvilStart));
    }

    public float mature(float a) {
        return smooth((a - matureStart) / 1500f);
    }

    public float dissipate(float a) {
        float start = life - Math.max(2400, life / 6);
        return smooth((a - start) / (life - start));
    }

    public boolean hasTornado() {
        return category >= 0 && tornStart >= 0;
    }

    /** 0..1 how far the funnel has descended (1 = touching the ground). */
    public float funnelLen(float a) {
        if (!hasTornado()) return 0f;
        float g = (a - tornStart) / tornGrow;
        if (g <= 0f) return 0f;
        float ropeStart = tornStart + tornGrow + tornHold;
        if (a >= ropeStart) {
            return 1f - smooth((a - ropeStart) / tornRope);
        }
        return smooth(g);
    }

    /** 0..1 width factor of the funnel (thins out into a rope when dying). */
    public float funnelWidth(float a) {
        if (!hasTornado()) return 0f;
        float g = (a - tornStart) / tornGrow;
        if (g <= 0f) return 0f;
        float ropeStart = tornStart + tornGrow + tornHold;
        if (a >= ropeStart) {
            return 0.12f + 0.88f * (1f - smooth((a - ropeStart) / tornRope));
        }
        return 0.35f + 0.65f * smooth(g);
    }

    public boolean touching(float a) {
        return funnelLen(a) >= 0.985f;
    }

    public float groundRadius(float a) {
        int c = Math.max(0, Math.min(5, category));
        return EF_RADIUS[c] * Math.max(0.15f, funnelWidth(a)) * (0.8f + 0.2f * size);
    }

    // ---- geometry ----
    public float towerRadius() {
        return 300f * size;
    }

    public float anvilRadius() {
        return 1700f * size;
    }

    public float towerHeight() {
        return (kind == KIND_SQUALL ? 480f : 640f) * size;
    }

    public float speed() {
        return (float) Math.hypot(vx, vz);
    }

    public float dirX() {
        float s = speed();
        return s > 1e-6f ? vx / s : 1f;
    }

    public float dirZ() {
        float s = speed();
        return s > 1e-6f ? vz / s : 0f;
    }

    /** Where the tornado touches the ground (x, z), at storm age a. */
    public void tornadoPos(float a, double[] out) {
        float dx = dirX(), dz = dirZ();
        float r = towerRadius();
        double ox = -dx * 0.15 * r - dz * 0.28 * r;
        double oz = -dz * 0.15 * r + dx * 0.28 * r;
        double wob = Math.sin(a * 0.011 + (seed & 1023)) * 18.0 * size;
        out[0] = x + ox - dz * wob;
        out[1] = z + oz + dx * wob;
    }

    /** Center of the precipitation core (rain shaft). */
    public void rainCenter(double[] out) {
        float dx = dirX(), dz = dirZ();
        float r = towerRadius();
        out[0] = x + dx * 0.30 * r + dz * 0.10 * r;
        out[1] = z + dz * 0.30 * r - dx * 0.10 * r;
    }

    public float rainRadius() {
        float k = kind == KIND_SQUALL ? 1.5f : (kind == KIND_SUPERCELL ? 1.15f : 1f);
        return 360f * size * k;
    }

    public float rainAmount() {
        switch (kind) {
            case KIND_SQUALL: return 1.0f;
            case KIND_SUPERCELL: return 0.95f;
            case KIND_DRY: return 0.12f;
            default: return 0.75f;
        }
    }

    public float lightningRate() {
        switch (kind) {
            case KIND_SQUALL: return 0.075f;
            case KIND_SUPERCELL: return 0.055f;
            case KIND_DRY: return 0.05f;
            default: return 0.04f;
        }
    }

    public float baseOffsetY() {
        switch (kind) {
            case KIND_SUPERCELL: return 0f;
            case KIND_SQUALL: return -15f;
            case KIND_DRY: return 70f;
            default: return 0f;
        }
    }

    /** How far the wall cloud (where the funnel hangs from) is lowered below the cloud base. */
    public float wallDrop() {
        return 50f * size;
    }

    // ---- network ----
    public void write(FriendlyByteBuf b) {
        b.writeVarInt(id);
        b.writeDouble(x);
        b.writeDouble(z);
        b.writeFloat(vx);
        b.writeFloat(vz);
        b.writeVarInt(age);
        b.writeByte(kind);
        b.writeFloat(size);
        b.writeLong(seed);
        b.writeVarInt(towerEnd);
        b.writeVarInt(anvilStart);
        b.writeVarInt(anvilEnd);
        b.writeVarInt(matureStart);
        b.writeVarInt(life);
        b.writeInt(tornStart);
        b.writeVarInt(tornGrow);
        b.writeVarInt(tornHold);
        b.writeVarInt(tornRope);
        b.writeByte(category);
    }

    public static StormData read(FriendlyByteBuf b) {
        StormData s = new StormData();
        s.id = b.readVarInt();
        s.x = b.readDouble();
        s.z = b.readDouble();
        s.vx = b.readFloat();
        s.vz = b.readFloat();
        s.age = b.readVarInt();
        s.kind = b.readByte();
        s.size = b.readFloat();
        s.seed = b.readLong();
        s.towerEnd = b.readVarInt();
        s.anvilStart = b.readVarInt();
        s.anvilEnd = b.readVarInt();
        s.matureStart = b.readVarInt();
        s.life = b.readVarInt();
        s.tornStart = b.readInt();
        s.tornGrow = b.readVarInt();
        s.tornHold = b.readVarInt();
        s.tornRope = b.readVarInt();
        s.category = b.readByte();
        return s;
    }

    // ---- global wind (same for server and client, depends only on the world seed) ----
    public static float windAngle(long worldSeed) {
        long h = worldSeed * 0x9E3779B97F4A7C15L;
        h ^= (h >>> 29);
        h *= 0xBF58476D1CE4E5B9L;
        h ^= (h >>> 32);
        double u = (h >>> 11) / (double) (1L << 53);
        return (float) (u * Math.PI * 2.0);
    }
}
