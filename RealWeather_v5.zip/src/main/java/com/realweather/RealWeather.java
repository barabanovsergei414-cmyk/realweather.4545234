package com.realweather;

import com.mojang.logging.LogUtils;
import com.realweather.command.RWCommands;
import com.realweather.net.FlashPayload;
import com.realweather.net.StormSyncPayload;
import com.realweather.storm.StormManager;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import org.slf4j.Logger;

@Mod(RealWeather.MODID)
public class RealWeather {
    public static final String MODID = "realweather";
    public static final Logger LOGGER = LogUtils.getLogger();

    public RealWeather(IEventBus modBus, ModContainer container) {
        container.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        RWSounds.SOUNDS.register(modBus);
        modBus.addListener(this::registerPayloads);
        NeoForge.EVENT_BUS.addListener(this::onLevelTick);
        NeoForge.EVENT_BUS.addListener(this::onRegisterCommands);
        NeoForge.EVENT_BUS.addListener(this::onServerStopped);
        NeoForge.EVENT_BUS.addListener(this::onPlayerLogin);
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(StormSyncPayload.TYPE, StormSyncPayload.CODEC,
                (payload, ctx) -> ctx.enqueueWork(() -> com.realweather.client.ClientPayloads.onSync(payload)));
        registrar.playToClient(FlashPayload.TYPE, FlashPayload.CODEC,
                (payload, ctx) -> ctx.enqueueWork(() -> com.realweather.client.ClientPayloads.onFlash(payload)));
    }

    private void onLevelTick(LevelTickEvent.Post event) {
        if (event.getLevel() instanceof ServerLevel level && level.dimension() == Level.OVERWORLD) {
            StormManager.INSTANCE.tick(level);
        }
    }

    private void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp && sp.level() instanceof ServerLevel level) {
            StormManager.INSTANCE.syncTo(level, sp);
        }
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        RWCommands.register(event.getDispatcher());
    }

    private void onServerStopped(ServerStoppedEvent event) {
        StormManager.INSTANCE.reset();
    }
}
