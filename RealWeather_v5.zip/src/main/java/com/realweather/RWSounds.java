package com.realweather;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class RWSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, RealWeather.MODID);

    public static final DeferredHolder<SoundEvent, SoundEvent> THUNDER_NEAR = reg("thunder_near");
    public static final DeferredHolder<SoundEvent, SoundEvent> THUNDER_MID = reg("thunder_mid");
    public static final DeferredHolder<SoundEvent, SoundEvent> THUNDER_ROLL = reg("thunder_roll");
    public static final DeferredHolder<SoundEvent, SoundEvent> THUNDER_FAR = reg("thunder_far");
    public static final DeferredHolder<SoundEvent, SoundEvent> TORNADO_ROAR = reg("tornado_roar");
    public static final DeferredHolder<SoundEvent, SoundEvent> STORM_WIND = reg("storm_wind");

    private static DeferredHolder<SoundEvent, SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(RealWeather.MODID, name)));
    }

    private RWSounds() {}
}
