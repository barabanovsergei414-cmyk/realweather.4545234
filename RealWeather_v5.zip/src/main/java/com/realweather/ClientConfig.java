package com.realweather;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Client side (graphics / sound) settings. */
public final class ClientConfig {
    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.BooleanValue SKY;
    public static final ModConfigSpec.BooleanValue CLOUDS;
    public static final ModConfigSpec.BooleanValue VOLUMETRIC;
    public static final ModConfigSpec.DoubleValue CLOUD_RESOLUTION;
    public static final ModConfigSpec.BooleanValue CLOUD_DEPTH;
    public static final ModConfigSpec.BooleanValue AMBIENT_CLOUDS;
    public static final ModConfigSpec.IntValue CLOUD_QUALITY;
    public static final ModConfigSpec.DoubleValue CLOUD_COVERAGE;
    public static final ModConfigSpec.IntValue CLOUD_DISTANCE;
    public static final ModConfigSpec.DoubleValue WIND_SPEED;
    public static final ModConfigSpec.BooleanValue CLOUD_SHADOWS;
    public static final ModConfigSpec.DoubleValue SHADOW_STRENGTH;
    public static final ModConfigSpec.BooleanValue RAIN_SHAFTS;
    public static final ModConfigSpec.BooleanValue LIGHTNING_VISUALS;
    public static final ModConfigSpec.DoubleValue FLASH_BRIGHTNESS;
    public static final ModConfigSpec.DoubleValue STORM_DARKNESS;
    public static final ModConfigSpec.BooleanValue STORM_FOG;
    public static final ModConfigSpec.BooleanValue DEBRIS_PARTICLES;
    public static final ModConfigSpec.DoubleValue THUNDER_VOLUME;
    public static final ModConfigSpec.DoubleValue AMBIENT_SOUND_VOLUME;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        b.comment("Sky and clouds").push("sky");
        SKY = b.comment("Replace the vanilla sky with the procedural sky (day, dusk, night, dawn, stars)").define("realisticSky", true);
        CLOUDS = b.comment("Draw volumetric clouds and storms (turns vanilla clouds off)").define("realisticClouds", true);
        VOLUMETRIC = b.comment("Solid volumetric clouds (ray-marched in a shader). Off = old cloud sprites").define("volumetricClouds", true);
        CLOUD_RESOLUTION = b.comment("Resolution of the cloud pass relative to the screen (lower = faster)").defineInRange("cloudResolution", 0.5, 0.25, 1.0);
        CLOUD_DEPTH = b.comment("Hide clouds behind terrain using the scene depth. Turn off only if clouds do not show at all").define("cloudDepthTest", true);
        AMBIENT_CLOUDS = b.comment("Draw everyday clouds (cumulus, stratus) besides storms").define("ambientClouds", true);
        CLOUD_QUALITY = b.comment("Cloud detail: 1 = low, 2 = medium, 3 = high, 4 = ultra").defineInRange("cloudQuality", 2, 1, 4);
        CLOUD_COVERAGE = b.comment("How cloudy the sky is in general (0..1.5)").defineInRange("cloudCoverage", 1.0, 0.0, 1.5);
        CLOUD_DISTANCE = b.comment("How far clouds are drawn (blocks)").defineInRange("cloudDistance", 5000, 1500, 9000);
        WIND_SPEED = b.comment("Cloud drift speed multiplier").defineInRange("windSpeed", 1.0, 0.0, 4.0);
        CLOUD_SHADOWS = b.comment("Cloud shadows on the ground").define("cloudShadows", true);
        SHADOW_STRENGTH = b.comment("Cloud shadow darkness").defineInRange("shadowStrength", 0.5, 0.0, 1.0);
        b.pop();
        b.comment("Storm look").push("storm");
        RAIN_SHAFTS = b.comment("Visible rain shafts under storm clouds").define("rainShafts", true);
        LIGHTNING_VISUALS = b.comment("Bolts, cloud flashes and glow").define("lightningVisuals", true);
        FLASH_BRIGHTNESS = b.comment("Lightning flash brightness").defineInRange("flashBrightness", 1.0, 0.0, 2.0);
        STORM_DARKNESS = b.comment("How dark it gets under a storm").defineInRange("stormDarkness", 0.8, 0.0, 1.0);
        STORM_FOG = b.comment("Reduce visibility in heavy rain").define("stormFog", true);
        DEBRIS_PARTICLES = b.comment("Block particles around the tornado base").define("debrisParticles", true);
        b.pop();
        b.comment("Sound").push("sound");
        THUNDER_VOLUME = b.comment("Thunder volume").defineInRange("thunderVolume", 1.0, 0.0, 1.5);
        AMBIENT_SOUND_VOLUME = b.comment("Storm wind and tornado volume").defineInRange("ambientSoundVolume", 1.0, 0.0, 1.0);
        b.pop();
        SPEC = b.build();
    }

    public static float qualityFactor() {
        switch (CLOUD_QUALITY.get()) {
            case 1: return 0.55f;
            case 3: return 1.6f;
            case 4: return 2.4f;
            default: return 1.0f;
        }
    }

    private ClientConfig() {}
}
