#version 150

in vec3 vDir;

uniform vec3 SunDir;
uniform vec4 Params;   // x = time (s), y = storm (0..1), z = cirrus (0..1), w = flash (0..1)
uniform vec4 Params2;  // x = wind x, y = wind z, z = overcast (0..1), w = unused

out vec4 fragColor;

float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float hash31(vec3 p) {
    p = fract(p * vec3(443.897, 441.423, 437.195));
    p += dot(p, p.yzx + 19.19);
    return fract((p.x + p.y) * p.z);
}

float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float s = 0.0;
    float a = 0.5;
    for (int i = 0; i < 5; i++) {
        s += a * vnoise(p);
        p = p * 2.03 + vec2(17.1, 9.2);
        a *= 0.5;
    }
    return s;
}

void main() {
    vec3 d = normalize(vDir);
    float sunY = SunDir.y;
    float mu = dot(d, SunDir);
    float h = d.y;
    float storm = Params.y;
    float overcast = Params2.z;

    float day = smoothstep(-0.18, 0.12, sunY);
    float dusk = exp(-pow(sunY / 0.16, 2.0));

    vec3 zenithDay = vec3(0.16, 0.36, 0.78);
    vec3 horizonDay = vec3(0.66, 0.79, 0.95);
    vec3 zenithNight = vec3(0.006, 0.010, 0.030);
    vec3 horizonNight = vec3(0.035, 0.050, 0.100);
    vec3 zen = mix(zenithNight, zenithDay, day);
    vec3 hor = mix(horizonNight, horizonDay, day);

    float g = pow(clamp(1.0 - max(h, 0.0), 0.0, 1.0), 3.2);
    vec3 col = mix(zen, hor, g);

    vec2 sunH = vec2(SunDir.x, SunDir.z);
    vec2 dH = vec2(d.x, d.z);
    float sunAz = max(dot(dH / (length(dH) + 1e-5), sunH / (length(sunH) + 1e-5)), 0.0);
    vec3 duskCol = vec3(1.0, 0.50, 0.26);
    vec3 duskHigh = vec3(0.50, 0.38, 0.62);
    float band = dusk * pow(g, 1.3) * (0.30 + 0.70 * pow(sunAz, 2.0));
    col = mix(col, duskCol, clamp(band * 0.95, 0.0, 1.0));
    col = mix(col, duskHigh, dusk * 0.30 * (1.0 - g) * pow(1.0 - sunAz, 1.5) * clamp(h * 3.0, 0.0, 1.0));

    vec3 sunCol = mix(vec3(1.0, 0.42, 0.16), vec3(1.0, 0.95, 0.85), smoothstep(0.0, 0.35, sunY));
    float sunVis = (1.0 - storm) * (1.0 - overcast * 0.85);
    float mie = pow(max(mu, 0.0), 6.0) * 0.22 + pow(max(mu, 0.0), 48.0) * 0.9;
    col += sunCol * mie * smoothstep(-0.2, 0.05, sunY) * sunVis;
    float disc = smoothstep(0.9972, 0.9984, mu);
    col = mix(col, sunCol * 3.0, disc * smoothstep(-0.05, 0.03, sunY) * sunVis);

    // stars + moon at night
    float night = 1.0 - smoothstep(-0.25, 0.02, sunY);
    if (night > 0.01 && h > -0.05) {
        vec3 sd = d * 160.0;
        vec3 id = floor(sd);
        vec3 fr = fract(sd) - 0.5;
        float hs = hash31(id);
        float star = step(0.9965, hs) * (1.0 - smoothstep(0.0, 0.38, length(fr)));
        float tw = 0.75 + 0.25 * sin(Params.x * (1.5 + hs * 4.0) + hs * 50.0);
        vec3 starCol = mix(vec3(0.75, 0.82, 1.0), vec3(1.0, 0.9, 0.75), hash31(id + 7.0));
        float cover = (1.0 - storm) * (1.0 - overcast);
        col += starCol * star * tw * night * 1.4 * cover;
        float b = dot(d, normalize(vec3(0.35, 0.55, 0.75)));
        float mw = exp(-pow(b / 0.20, 2.0)) * fbm(d.xz * 6.0 / (abs(d.y) + 0.6) + 3.0);
        col += vec3(0.10, 0.11, 0.16) * mw * night * cover;
    }
    vec3 moonDir = -SunDir;
    float mm = dot(d, moonDir);
    float moonUp = smoothstep(-0.05, 0.1, moonDir.y);
    float moonDisc = smoothstep(0.9978, 0.9986, mm);
    float moonCover = (1.0 - storm) * (1.0 - overcast * 0.8);
    col += vec3(0.78, 0.82, 0.92) * moonDisc * moonUp * 1.1 * moonCover;
    col += vec3(0.25, 0.30, 0.42) * pow(max(mm, 0.0), 60.0) * moonUp * 0.5 * moonCover;

    // high thin cloud layer (cirrus / cirrostratus), procedural
    float cirrus = Params.z;
    if (h > 0.015 && cirrus > 0.01) {
        vec2 p = d.xz / (h + 0.14);
        p += Params2.xy * Params.x * 0.003;
        vec2 q = vec2(p.x * 0.9 + 3.1, p.y * 2.9);
        float n = fbm(q + 1.6 * fbm(p * 1.7));
        float c = smoothstep(0.52 - 0.26 * cirrus, 0.88, n) * cirrus;
        c *= smoothstep(0.015, 0.22, h);
        float lit = clamp(day + dusk * 0.6, 0.0, 1.0);
        vec3 ccol = mix(vec3(0.05, 0.06, 0.10), vec3(0.95, 0.96, 1.0), lit);
        ccol = mix(ccol, duskCol * 1.1, dusk * pow(sunAz, 2.0) * 0.8);
        col = mix(col, ccol, clamp(c * 0.85, 0.0, 0.95));
    }

    // storm / overcast
    vec3 stormCol = mix(vec3(0.20, 0.23, 0.24), vec3(0.42, 0.47, 0.38), pow(g, 2.0)) * (0.16 + 0.84 * day);
    col = mix(col, stormCol, storm * 0.90);
    vec3 grey = mix(vec3(0.05, 0.055, 0.07), mix(vec3(0.48, 0.52, 0.56), vec3(0.72, 0.74, 0.76), g), day) ;
    col = mix(col, grey, overcast * 0.78);

    // below the horizon: blend to horizon colour (matches terrain fog)
    float below = 1.0 - smoothstep(-0.20, 0.0, h);
    vec3 horOut = mix(hor, duskCol, dusk * 0.5);
    horOut = mix(horOut, stormCol, storm * 0.90);
    horOut = mix(horOut, grey, overcast * 0.78);
    col = mix(col, horOut * (1.0 - 0.25 * below), below);

    col += vec3(0.55, 0.62, 0.90) * Params.w * (0.45 + 0.55 * g);

    col = col / (1.0 + col * 0.18);
    fragColor = vec4(col, 1.0);
}
